# 👨‍🎓 Education

`2016 - 2018` IIITM-Kerala (DUK) @ Cochin University of Science and Technology
- **M.Phil.** in Computer Science

`2013 - 2015` U.I.T Mulamkadakam @ University of Kerala
- **M.Sc.** in Computer Science

`2010 - 2013` U.I.T Adoor @ University of Kerala
- **B.Sc.** in Computer Science
