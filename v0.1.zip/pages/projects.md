# 🧪 Projects

## [Ethereum Faucet](https://github.com/ananthanir/ethereum-faucet)🔗
- A simple ethereum facucet application for Private Networks. Build using React and Ether.js